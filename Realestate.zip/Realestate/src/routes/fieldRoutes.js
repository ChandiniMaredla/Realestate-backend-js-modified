const express = require('express');
const { getFields,insertFieldDetails } = require('../controllers/fieldController');

const fieldRoutes = express.Router();

fieldRoutes.get('/', getFields);
fieldRoutes.post('/insert', insertFieldDetails);


module.exports = fieldRoutes;
