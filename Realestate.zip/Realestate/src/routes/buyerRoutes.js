const express = require('express');
const { getBuyers, createBuyer } = require('../controllers/buyersController');

const buyersRoutes = express.Router();

buyersRoutes.get('/getbuyerdetails', getBuyers);
buyersRoutes.post('/create', createBuyer);
// buyersRoutes.put('/update/:_id', updateBuyer);
// buyersRoutes.delete('/delete/:_id', deleteBuyer);

module.exports = buyersRoutes;
