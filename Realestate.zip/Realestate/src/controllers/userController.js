const express = require('express');
const bcrypt = require('bcrypt');
const userModel = require('../models/userModel'); 
const saltRounds = 10;

// Controller to get all users
const getUsers = async (req, res) => {
    try {
        const data = await userModel.find();
        res.send(data);
    } catch (error) {
        res.status(500).send(error);
    }
};

// Controller to create a new user
const createUser = async (req, res) => {
    try {
        const user = new userModel({ ...req.body });
        const salt = await bcrypt.genSalt(saltRounds);
        const hashedPassword = await bcrypt.hash(user.password, salt);
        user.password = hashedPassword;

        console.log(user);

        user.save()
            .then(() => {
                res.send({ message: "User Added Successfully", success: true });
            })
            .catch((error) => {
                res.status(400).send(error);
            });
    } catch (error) {
        res.status(500).send(error);
    }
};

// Controller to update a user
const updateUser = async (req, res) => {
    try {
        const userId = req.params._id;
        const updateData = req.body;

        const user = await userModel.findByIdAndUpdate(userId, updateData, { new: true, runValidators: true });
        if (!user) {
            return res.status(404).send({ message: "User not found", success: false });
        }

        res.send({ message: "User Updated Successfully", success: true, user });
    } catch (error) {
        res.status(500).send(error);
    }
};

// Controller to delete a user
const deleteUser = async (req, res) => {
    try {
        const userId = req.params._id;

        const user = await userModel.findByIdAndDelete(userId);
        if (!user) {
            return res.status(404).send({ message: "User not found", success: false });
        }

        res.send({ message: "User Deleted Successfully", success: true });
    } catch (error) {
        res.status(500).send(error);
    }
};

module.exports = {
    createUser,
    deleteUser,
    getUsers,
    updateUser,
};
